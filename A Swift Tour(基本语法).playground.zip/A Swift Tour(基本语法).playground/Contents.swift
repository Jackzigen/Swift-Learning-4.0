//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


//常量
let myConstant = 42

//变量 
var myVariable = 42
myVariable = 50

//类型推断  swift会根据初始值来推断值的类型
let implicitInteger = 70
let implicitDouble  = 70.0
//有时候设置的初始值信息不足以推断类型时，可通过冒号: 来设置
let explicitDouble:Double = 70

let explicitFloat:Float = 4

//类型转变
let label = "The Width is "
let width = 94
let widthLabel = label + String(width)
//不可变的  不能移除里面内容

//比上面更简单的方法  string中加数字
let apples  = 3
let oranges = 5
let appleSummary = "I have \(apples) apples"
let fruitSummary = "I have \(oranges + apples) pieces of fruit."

//练习
let aFloat:Float = 3.1
let bFloat:Float = 5
//let floatSummary = aFloat + bFloat
let someoneGreeting = "韩先生 calculate The total money is \(bFloat + aFloat)."

//👇这个不太明白！
//对于占用多行的字符串，使用三个双引号（“”“），只要与引用的缩写匹配，每个引用行开始处的缩进就会被删除，例如：
//let quotation = """
//Even though there's whitespace to the left,
//the actual lines aren't indented.
//Except for this line.
//Double quotes (") can appear without being escaped.
//
//I still have \(apples + oranges) pieces of fruit.
//"""

//数组
var shoppingList = ["fish","apple","water"]
shoppingList[1] = "bottle of water"
shoppingList

//字典
var occupations = ["Malcolm":"Captain","Kaylee":"Mechanic",]
occupations["Jack"] = "Public Relations"
occupations

//创建空数组  空字典
let emptyArray = [String]()
let emptyDictionary = [String:Float]()

//类型可以推断的时候  可以直接设置空数组 空字典
shoppingList = []
occupations  = [:]



/**
 * 条件控制
 */

//用if switch 做条件判断
//用for-in, while, and repeat-while 做循环处理
let individualScores = [75,43,102,87,12]
var teamScore = 0

for score in individualScores {
    if score > 50 {
        teamScore += 3
    }
    else{
        teamScore += 1
    }
}

print(teamScore)


//if 的条件  必须是BOOL值  与OC不一样

//可选值
//可选值要么 有一个值，要么 置成nil
//An optional value either contains a value or contains nil to indicate that a value is missing
//写法
//Write a question mark (?) after the type of a value to mark the value as optional.

//
var optionalString:String? = "Hello"
print(optionalString == nil)

//条件判断
//var optionalName:String? = "Jack"
//需加问号(可选值)才能置nil，可自行尝试
var optionalName:String? = nil
var greeting = "Hello!"

if let name = optionalName {
    greeting = "Hello,\(name)"
}
else{
    greeting = "惨了"
}

//?? 前面的不满足 就取后面的
let nickName:String? = nil
let fullName:String  = "ZiGen Han"
let informalGreeting = "Hi, \(nickName ?? fullName)"

//switch 支持integers、string  还支持啥？
let vegetable = "red pepper"
switch vegetable {
case "celery":
    print("Add some raisins and make ants on a log.")
case "apple","orange":
    print("apple or orange is also good")
case let x where x.hasSuffix("pepper"):
    print("I like \(x)")
default:
    print("Everything tastes good in soup")
}

//for - in 用在字典

let interestingNumbers = [
    "Prime"    :[2,3,5,7,11,13],
    "Fibonacci":[1,1,2,3,5,8],
    "Square"   :[1,4,9,16,25]
]

var largest = 0
var largestLocation:String? = nil
for (kind,numbers) in interestingNumbers {
    for number in numbers {
        if number > largest {
            largest = number
            largestLocation = kind
        }
    }
}

print(largest,largestLocation)

//while
//条件写在前面 用在代码块中，直到条件改变
var n = 2
while n < 100 {
    n *= 2
}
print(n)

//条件写在后面  但得确保条件至少执行一次
var m = 2
repeat{
    m *= 2
}while m < 100

print(m)


//..<  一定区间index 不包括边界
//...  包括边界
var totalValue = 0
for i in 0..<4 {
    totalValue += i
}
print(totalValue)




/**
 * 方法和闭包
 */
//用 -> 来分隔 参数和返回类型
func greet(person:String,day:String) -> String{
    return "Hello \(person),today is \(day)"
}
greet(person: "Jack", day: "Tuesday")

func greetLunch(person:String,detail:String) -> String{
    return "Hay \(person),do you \(detail) lunch"
}
greetLunch(person: "Bob", detail: "enjoy")


//增加_ 来隐藏和避免一些有争议的标签
func greet(_ person:String,on day:String) ->String{
    return "Hello \(person),today is \(day)"
}
greet("Jane", on: "Friday")



//元组
//使用元组创建复合值
func caculateStatistics(scores:[Int]) -> (min:Int,max:Int,sum:Int){
    var minScore = scores[0]
    var maxScore = scores[0]
    var sum = 0
    
    for score in scores {
        if score > maxScore {
            maxScore = score
        }else if score < minScore {
            minScore = score
        }
        
        sum += score
    }
    
    return (minScore,maxScore,sum)
}

let statistics = caculateStatistics(scores: [23,45,12,98,63])
//通过. 来获取对应位置的返回值
print(statistics.sum)
print(statistics.2)


//函数可以嵌套
//嵌套函数可以访问在外部函数中声明的变量,可以在长或复杂的函数中使用嵌套函数。

func returnFifteen () -> Int{
    var y = 10
    
    func add(){
        y += 5
    }
    add()
    return y
}

returnFifteen()


//返回值为函数
func makeIncrementer() -> ((Int)->Int){
    func addOne(number:Int) -> Int{
        return 1+number
    }
    
    return addOne
}

var incrementer = makeIncrementer()  //返回的是addOne
incrementer(7)                       //相当于addOne 赋值


//参数为函数
func hasAnyMatches(_ list:[Int],condition:(Int)->Bool) -> Bool{
    for item in list {
        if condition(item) {
            return true
        }
    }
    return false
}

func lessThanTen(number:Int) -> Bool{
    return number < 10
}

var numbers = [20,19,7,12]

hasAnyMatches(numbers, condition: lessThanTen)
//可以直接lessThanTen 这样写     不用lessThanTen(参数)  



//看不懂  what? 会报错
//Functions are actually a special case of closures: blocks of code that can be called later. The code in a closure has access to things like variables and functions that were available in the scope where the closure was created, even if the closure is in a different scope when it is executed—you saw an example of this already with nested functions. You can write a closure without a name by surrounding code with braces ({}). Use in to separate the arguments and return type from the body
//函数实际上是一个特殊的闭包情况：稍后可以调用的代码块。闭包中的代码可以访问在创建关闭的范围内可用的变量和函数，即使在执行闭包时，闭包也处于不同的范围 - 您已经看到已经有嵌套函数的示例。您可以使用括号（{}）编写一个没有名称的封面。用于将参数和返回类型与正文分开。
//numbers.map ({(number:Int) -> Int in
//    let result = 3 * number
//    result result
//})


//报错
//有几个更简洁地方式写闭包。当闭包类型已经知道时，例如代理的回调，您可以省略其参数的类型，其返回类型或两者。单个语句闭包隐式地返回它们唯一的语句的值
//let mappedNumbers = numbers.map({number in 3 *number})
//print(mappedNumbers)


//You can refer to parameters by number instead of by name—this approach is especially useful in very short closures. A closure passed as the last argument to a function can appear immediately after the parentheses. When a closure is the only argument to a function, you can omit the parentheses entirely
let sortedNumbers = numbers.sorted { $0 > $1 }
print(sortedNumbers)


/**
 *  对象和类
 *
 */

//类 方法的写法跟上面的Int类型等 写法类似
class Shape{
    var numberOfSides = 0
    
    func simpleDescription() -> String {
        return "A shape with \(numberOfSides) sides"
    }
    
    let numberOfAngles = 0
    func simpleDescriptionAngle() -> String {
        return "Hexagonal star has \(numberOfAngles) angles"
    }
    
}

//通过在类名后添加括号来创建类的实例，通过.语法来访问属性
var shape = Shape()
shape.numberOfSides = 7

var shapeDescription = shape.simpleDescription()

//初始化init 设值
class NamedShape {
    var numberOfSides = 0
    var name: String
    
    init(nameTemp:String){
        self.name = nameTemp
    }
    
    func shapeDescription()->String{
        return "A shape with \(numberOfSides) sides"
    }
}


//重写父类的方法  需加 override
class Square:NamedShape {//继承父类
    var sideLength:Double
    
    init(sideLength:Double,name:String) {
        self.sideLength = sideLength
        super.init(nameTemp: name)
        numberOfSides = 10
    }
    
    func area() -> Double {
        return sideLength*sideLength
    }
    
    override func shapeDescription() -> String {
        return "A square with sides length \(sideLength)"
    }
    
}

let test = Square.init(sideLength: 5.2, name: "my test square")
test.area()
test.shapeDescription()



//练习
class Circle:NamedShape{
    var radiusLength:Double
    
    init(radiusLength:Double,name:String) {
        self.radiusLength = radiusLength
        super.init(nameTemp: name)
        
    }
    
    func area() -> Double {
        return 3.14*radiusLength*radiusLength
    }
    
    override func shapeDescription() -> String {
        return "A Circle with radius length \(radiusLength)"
    }
    
}

let circle = Circle.init(radiusLength: 5, name: "Circle story")
circle.area()
circle.shapeDescription()













